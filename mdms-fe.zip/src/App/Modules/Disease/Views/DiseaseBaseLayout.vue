<template>
  <main-layout>
    <template slot="content">
      <router-view></router-view>
    </template>
  </main-layout>
</template>

<script>
export default {
  name: "DiseaseBaseLayout",
  components: {},
};
</script>