export const SET_TOKEN = "SET_TOKEN";
export const UNSET_TOKEN = "UNSET_TOKEN";
export const SET_USER = "SET_USER";
export const UNSET_USER = "UNSET_USER";
